from flask import Flask, request, jsonify, render_template
import util

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predicted_price', methods=['POST'])
def predict_price():
    airline = request.form['airline']
    source_city = request.form['source_city']
    departure_time = request.form['departure_time']
    stops = request.form['stops']
    arrival_time = request.form['arrival_time']
    destination_city = request.form['destination_city']
    classes = request.form['class']

    prediction = util.predict_price(airline, source_city, departure_time, stops, arrival_time, destination_city, classes)

    return jsonify({"predicted_price": prediction})

if __name__ == '__main__':
    app.run(debug=True)
