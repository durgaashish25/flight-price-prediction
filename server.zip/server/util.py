import json
import pickle
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
__data_columns=None
__model=None
def predict_price(airline,source_city,departure_time,stops,arrival_time,destination_city,classes):
    file_path= r"C:\Users\ASHISH PC\Downloads\Clean_Dataset.csv\Clean_Dataset.csv"
    df=pd.read_csv(file_path)
    df=df.drop(columns=["duration","days_left"],axis=True) 
    label_encoder_airline=LabelEncoder()
    label_encoder_source_city=LabelEncoder()
    label_encoder_departure_time=LabelEncoder()
    label_encoder_stops=LabelEncoder()
    label_encoder_arrival_time=LabelEncoder()
    label_encoder_destination_city=LabelEncoder()
    label_encoder_class=LabelEncoder()
    df['airline']=label_encoder_airline.fit_transform(df['airline'])
    df['source_city']=label_encoder_source_city.fit_transform(df['source_city'])
    df['departure_time']=label_encoder_departure_time.fit_transform(df['departure_time'])
    df['stops']=label_encoder_stops.fit_transform(df['stops'])
    df['arrival_time']=label_encoder_arrival_time.fit_transform(df['arrival_time'])
    df['destination_city']=label_encoder_destination_city.fit_transform(df['destination_city'])
    df['class']=label_encoder_class.fit_transform(df['class'])
    features=["airline","source_city","departure_time","stops","arrival_time","destination_city","class"]
    target="price"
    X=df[features]
    Y=df[target]
    X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.2,random_state=42)
    __model=RandomForestRegressor(random_state=42)
    __model.fit(X_train,Y_train)
    airline_encoded=label_encoder_airline.transform([airline])[0]
    source_city_encoded=label_encoder_source_city.transform([source_city])[0]
    departure_time_encoded=label_encoder_departure_time.transform([departure_time])[0]
    stops_encoded=label_encoder_stops.transform([stops])[0]
    arrival_time_encoded=label_encoder_arrival_time.transform([arrival_time])[0]
    destination_city_encoded=label_encoder_destination_city.transform([destination_city])[0]
    classes_encoded=label_encoder_class.transform([classes])[0]
    input_data=np.array([[airline_encoded,source_city_encoded,departure_time_encoded,stops_encoded,arrival_time_encoded,destination_city_encoded,classes_encoded]])
    predicted_price=__model.predict(input_data)
    return f"Predicted flight price: $ {predicted_price}"
def load_saved_artifacts():
    print("loading saved artifacts...start")
    global __model
    global __data_columns
    with open("./artifacts/columns.json",'r') as f:
        __data_columns=json.load(f)['data_columns']
    with open("./artifacts/flight_price_prediction.pickle","rb") as f:
        __model=pickle.load(f)
    print("loading saved artifacts...done")
if __name__ == '__main__':
    load_saved_artifacts()
    print(predict_price('AirAsia','Delhi','Morning','zero','Night','Mumbai','Economy'))
